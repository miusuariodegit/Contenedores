class Post < ApplicationRecord
end
