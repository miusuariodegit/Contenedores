<template>
  <div>
    <Posts />
  </div>
</template>
<script setup>
import Posts from './components/Posts.vue'
</script>

<style scoped>
</style>
